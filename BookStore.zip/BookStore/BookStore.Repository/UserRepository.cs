﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BookStore.Model.Models;
using BookStore.Model.ViewModel;

namespace BookStore.Repository
{
    public class UserRepository : BaseRepository
    {
        BookStoreContext _context = new BookStoreContext();

        public List<User> GetUsers()
        {
            return _context.Users.ToList();

        }

        public User Login(LoginModel model)
        {
            return (_context.Users.FirstOrDefault(c => c.Email.Equals(model.Email.ToLower()) && c.Password.Equals(model.Password)));
        }

        public User Login()
        {
            throw new NotImplementedException();
        }

        public User Register(RegisterModel model)
        {
            User user = new User()
            {
                Email = model.Email,
                Password = model.Password,
                Firstname = model.Firstname,
                Lastname = model.Lastname,
                RoleId = model.Roleid,


            };
            var entity = _context.Users.Add(user);
            _context.SaveChanges();
            return entity.Entity;
        }

        public ListResponse<Role> GetAllRoles()
        {

           var query = _context.Roles.AsQueryable();
           var totalRecords = query.Count();
           var results = new ListResponse<Role>()
           {
               Results = query.ToList(),
               TotalRecords = totalRecords

           };
           return results;

        }
    }
}
