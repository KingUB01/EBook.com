﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BookStore.Model.ViewModel;

namespace BookStore.Repository
{
    public class BaseRepository
    {
       protected readonly BookStoreContext _context = new BookStoreContext();
    }
}
