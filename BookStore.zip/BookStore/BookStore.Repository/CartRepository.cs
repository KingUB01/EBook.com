﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BookStore.Model.ViewModel;
using Microsoft.EntityFrameworkCore;

namespace BookStore.Repository
{
    public class CartRepository: BaseRepository
    {
        public List<Cart> GetCartItems(string keyword)
        {

            keyword = keyword?.ToLower().Trim();
            var query = _context.Carts.Include(c=> c.Book).ToList().Where(c => keyword == null || c.Book.Name.ToLower().Contains(keyword)).AsQueryable();
            return query.ToList();

          
        }

        public Cart GetCarts(int id)
        {
            return _context.Carts.FirstOrDefault(c => c.Id == id);
        }

        public Cart AddCart(Cart Cart)
        {
            var entry = _context.Carts.Add(Cart);
            _context.SaveChanges();
            return entry.Entity;
        }

        public Cart UpdateCart(Cart Cart)
        {
            var entry = _context.Carts.Update(Cart);
            _context.SaveChanges();
            return entry.Entity;
        }

        public bool DeleteCart(int id)
        {
            var Cart = _context.Carts.FirstOrDefault(c => c.Id == id);
            if (Cart == null)
                return false;

            var entry = _context.Carts.Remove(Cart);
            _context.SaveChanges();
            return true;
        }
    }
}
