﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BookStore.Model.Models;
using BookStore.Model.ViewModel;

namespace BookStore.Repository
{
    public class CategoryRepository : BaseRepository
    {
        public ListResponse<Category> GetCategories(int pageIndex , int pageSize , string keyword)
        {
            
            keyword = keyword?.ToLower().Trim();
           var query= _context.Cart.Where(c => keyword == null || c.Name.ToLower().Contains(keyword)).AsQueryable();
            int totalRecords = query.Count();
            List<Category> categories = query.Skip((pageIndex-1)*pageSize).Take(pageSize).ToList();

            return new ListResponse<Category>()
            {
                Results = categories,
                TotalRecords = totalRecords,
            };
        }

        public Category GetCategory(int id)
        {
            return _context.Cart.FirstOrDefault(c => c.Id == id);
        }

        public Category Addcategory(Category category)
        {
            var entry= _context.Cart.Add(category);
            _context.SaveChanges();
            return entry.Entity;
        }

        public Category Updatecategory(Category category)
        {
            var entry = _context.Cart.Update(category);
            _context.SaveChanges();
            return entry.Entity;
        }

        public bool DeleteCategory(int id)
        {
            var category = _context.Cart.FirstOrDefault(c => c.Id == id);
            if (category == null)
                return false;

            var entry = _context.Cart.Remove(category);
            _context.SaveChanges();
            return true;
        }

    }
}
