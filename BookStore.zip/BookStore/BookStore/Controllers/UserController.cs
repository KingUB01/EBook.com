﻿using Microsoft.AspNetCore.Mvc;
using BookStore.Repository;
using BookStore.Model.ViewModel;
using BookStore.Model.Models;
using System.Linq;

namespace BookStore.Controllers
{
    [ApiController]
    [Route("api/user")]
    public class UserController : ControllerBase
    {
        UserRepository _repository = new UserRepository();

        [HttpGet]
        [Route("GetUser")]
        public IActionResult GetUser()
        {
            return Ok(_repository.GetUsers());

        }

        [HttpPost]
        [Route("Login")]
        public IActionResult Login(LoginModel model)
        {
            User user = _repository.Login(model);
            if (user == null)
                return NotFound();

            return Ok(user);
        }

        [HttpPost]
        [Route("Register")]
        public IActionResult Register(RegisterModel model)
        {
            User user = _repository.Register(model);
            if (user == null)
                return BadRequest();

            return Ok(user);
        }

        [HttpGet]
        [Route("Roles")]
        public IActionResult GetAllRoles()
        {
            var roles = _repository.GetAllRoles();
            ListResponse<RoleModel> listResponse = new()
            {
                Results = roles.Results.Select(r => new RoleModel(r)).ToList(),
                TotalRecords = roles.TotalRecords
            };
           return Ok(roles);
        }



    }
}