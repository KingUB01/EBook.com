﻿using System.Collections.Generic;
using System.Linq;
using System.Net;
using BookStore.Model.Models;
using BookStore.Model.ViewModel;
using BookStore.Repository;
using Microsoft.AspNetCore.Mvc;

namespace BookStore.Controllers
{
    [ApiController]
    [Route("api/cart")]
    public class CartController : Controller
    {
        private readonly CartRepository _cartRepository = new CartRepository();
        

        [HttpGet]
        [Route("list")]
        public IActionResult GetCartItems( string keyword)
        {
            List<Cart> carts = _cartRepository.GetCartItems(keyword);
            IEnumerable<CartModel> cartModel = carts.Select(c => new CartModel(c));
            return Ok(cartModel);
        }

        [Route("{id}")]
        [HttpGet]
        [ProducesResponseType(typeof(ListResponse<CategoryModel>), (int)HttpStatusCode.OK)]
        public IActionResult GetCategory(int id)
        {
            var carts = _cartRepository.GetCarts(id);
            CartModel categorymodel = new CartModel(carts);


            return Ok(categorymodel);
        }

        [HttpPost]
        [Route("Add")]
        public IActionResult AddCart(CartModel model)
        {
            if (model == null)
                return BadRequest();
            Cart cart = new Cart()
            {
                Id = model.Id,
                Quantity = 1,
                Bookid = model.BookId,
                Userid = model.UserId,
            };
            _cartRepository.AddCart(cart);

            CartModel cartModel = new CartModel(cart);
            return Ok(cartModel);
        }

        [HttpPut]
        [Route("Update")]
        public IActionResult UpdateCart(CartModel model)
        {
            if (model == null)
                return BadRequest();
            Cart cart = new Cart()
            {
                Id = model.Id,
                Quantity = model.Quantity,
                Bookid = model.BookId,
                Userid = model.UserId,
            };
            _cartRepository.AddCart(cart);

            CartModel cartModel = new CartModel(cart);
            return View();
        }
        [HttpDelete]
        [Route("Remove")]
        public IActionResult DeleteCart(int id)
        {
            if (id == 0)
                return BadRequest();

            bool response = _cartRepository.DeleteCart(id);
            return Ok(response);
        }
    }
}
