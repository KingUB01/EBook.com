﻿using System.Linq;
using System.Net;
using BookStore.Model.Models;
using BookStore.Model.ViewModel;
using BookStore.Repository;
using Microsoft.AspNetCore.Mvc;

namespace BookStore.Controllers
{
    [ApiController]
    [Route("api/book")]
    public class BookController : ControllerBase
    {
        BookRepository _bookRepository = new BookRepository();
        [HttpGet]
        [Route("list")]
        public IActionResult GetBooks(int pageIndex = 1, int pageSize = 10, string keyword = "")
        {
           var books= _bookRepository.GetBooks(pageIndex, pageSize, keyword);

            ListResponse<BookModel> listResponse = new ListResponse<BookModel>()
            {
                Results = books.Results.Select(c => new BookModel(c)),

                TotalRecords = books.TotalRecords,
            };

            return Ok(listResponse);


        }

        [Route("{id}")]
        [HttpGet]
        [ProducesResponseType(typeof(ListResponse<BookModel>), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ListResponse<BookModel>), (int)HttpStatusCode.NotFound)]
        public IActionResult GetBook(int id)
        {
            var book = _bookRepository.GetBook(id);
            if (book == null)
                return NotFound();
            BookModel bookmodel = new BookModel(book);


            return Ok(bookmodel);
        }

        [Route("add")]
        [HttpPost]
        [ProducesResponseType(typeof(ListResponse<BookModel>), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ListResponse<BadRequestObjectResult>), (int)HttpStatusCode.BadRequest)]
        public IActionResult AddBook(BookModel model)
        {
            if (model == null)
                return BadRequest("model is null");

            Book book = new Book()
            {
                Id = model.Id,
            Name = model.Name,
            Price = model.Price,
            Description = model.Description,
            Base64image = model.Base64image,
            Categoryid = model.Categoryid,
            Publisherid = model.Publisherid,
            Quantity = model.Quantity,
        };

            var response = _bookRepository.AddBook(book);
            BookModel bookmodel = new BookModel(book);


            return Ok(bookmodel);
        }

        [Route("update")]
        [HttpPut]
        [ProducesResponseType(typeof(ListResponse<BookModel>), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ListResponse<BadRequestObjectResult>), (int)HttpStatusCode.BadRequest)]
        public IActionResult UpdateBook(BookModel model)
        {
            if (model == null)
                return BadRequest("model is null");
            Book Book = new Book()
            {
                Id = model.Id,
                Name = model.Name,
                Price = model.Price,
                Description = model.Description,
                Base64image = model.Base64image,
                Categoryid = model.Categoryid,
                Publisherid = model.Publisherid,
                Quantity = model.Quantity,
            };

            var response = _bookRepository.UpdateBook(Book);
            BookModel bookmodel = new BookModel(response);


            return Ok(bookmodel);
        }

        [Route("delete/{id}")]
        [HttpDelete]
        [ProducesResponseType(typeof(ListResponse<BookModel>), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ListResponse<BadRequestObjectResult>), (int)HttpStatusCode.BadRequest)]
        public IActionResult DeleteBook(int id)
        {
            if (id == 0)
                return BadRequest("id 0 is not velid");

            var response = _bookRepository.DeleteBook(id);

            return Ok(response);
        }
    }
}
