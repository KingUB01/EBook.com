﻿using System.Linq;
using System.Net;
using BookStore.Model.Models;
using BookStore.Model.ViewModel;
using BookStore.Repository;
using Microsoft.AspNetCore.Mvc;

namespace BookStore.Controllers
{
    [Route("api/category")]
    [ApiController]
    public class CategoryController : ControllerBase
    {
        CategoryRepository _categoryrepository = new CategoryRepository();

        [Route("list")]
        [HttpGet]
        [ProducesResponseType(typeof(ListResponse<CategoryModel>), (int)HttpStatusCode.OK)]
        public IActionResult GetCategories(int pageIndex = 1, int pageSize = 10, string keyword = "")
        {
            var categories = _categoryrepository.GetCategories(pageIndex, pageSize, keyword);
            ListResponse<CategoryModel> listResponse = new ListResponse<CategoryModel>()
            {
                Results = categories.Results.Select(c => new CategoryModel(c)),

                TotalRecords = categories.TotalRecords,
            };

            return Ok(listResponse);
        }

        [Route("{id}")]
        [HttpGet]
        [ProducesResponseType(typeof(ListResponse<CategoryModel>), (int)HttpStatusCode.OK)]
        public IActionResult GetCategory(int id)
        {
            var category = _categoryrepository.GetCategory(id);
            CategoryModel categorymodel = new CategoryModel(category);
            

            return Ok(categorymodel);
        }

        [Route("add")]
        [HttpPost]
        [ProducesResponseType(typeof(ListResponse<CategoryModel>), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ListResponse<BadRequestObjectResult>), (int)HttpStatusCode.BadRequest)]
        public IActionResult AddCategory(CategoryModel model)
        {
            if(model == null)
                return BadRequest("model is null");

            Category category = new Category()
            {
                Id = model.Id,
                Name = model.Name,
            };
     
            var response = _categoryrepository.Addcategory(category);
            CategoryModel categorymodel = new CategoryModel(category);


            return Ok(categorymodel);
        }

        [Route("update")]
        [HttpPut]
        [ProducesResponseType(typeof(ListResponse<CategoryModel>), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ListResponse<BadRequestObjectResult>), (int)HttpStatusCode.BadRequest)]
        public IActionResult UpdateCategory(CategoryModel model)
        {
            if (model == null)
                return BadRequest("model is null");
            Category category = new Category()
            {
                Id = model.Id,
                Name = model.Name,
            };

            var response = _categoryrepository.Updatecategory(category);
            CategoryModel categorymodel = new CategoryModel(response);


            return Ok(categorymodel);
        }

        [Route("delete/{id}")]
        [HttpDelete]
        [ProducesResponseType(typeof(ListResponse<CategoryModel>), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ListResponse<BadRequestObjectResult>), (int)HttpStatusCode.BadRequest)]
        public IActionResult DeleteCategory(int id)
        {
            if (id==0)
                return BadRequest("id 0 is not velid");

            var response = _categoryrepository.DeleteCategory(id);
          
            return Ok(response);
        }
    }
}

